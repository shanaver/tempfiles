# frozen_string_literal: true

module Aws
  module Stubbing
    module Protocols
      class ApiGateway < RestJson
      end
    end
  end
end
