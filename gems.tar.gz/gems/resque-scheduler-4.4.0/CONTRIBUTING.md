Resque Scheduler contribution guidelines
========================================

- Pull requests welcome!
- Please add yourself to [AUTHORS.md](AUTHORS.md) alphabetically by
first name.
