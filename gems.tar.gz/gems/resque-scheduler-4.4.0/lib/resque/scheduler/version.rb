# vim:fileencoding=utf-8

module Resque
  module Scheduler
    VERSION = '4.4.0'.freeze
  end
end
