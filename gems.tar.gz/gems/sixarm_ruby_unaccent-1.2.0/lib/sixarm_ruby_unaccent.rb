# -*- coding: utf-8 -*-
=begin rdoc
Please see README
=end

require_relative "sixarm_ruby_unaccent/string"
