module Fog
  module Xml
    VERSION = "0.1.3"
  end
end
