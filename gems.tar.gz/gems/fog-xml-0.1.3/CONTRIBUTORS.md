* Michael Hale <mike@hales.ws>
* Paul Thornthwaite <tokengeek@gmail.com>
* Paulo Henrique Lopes Ribeiro <plribeiro3000@gmail.com>
* Wesley Beary <geemus@gmail.com>
* Tomer Brisker <tbrisker@gmail.com>
