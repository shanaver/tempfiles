require 'spec_helper'

describe Zxcvbn::Scorer do

end