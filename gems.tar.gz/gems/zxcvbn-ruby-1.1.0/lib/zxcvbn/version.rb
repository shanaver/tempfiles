module Zxcvbn
  VERSION = '1.1.0'.freeze
end
