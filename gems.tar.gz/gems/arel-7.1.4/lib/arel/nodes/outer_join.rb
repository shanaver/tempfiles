module Arel
  module Nodes
    class OuterJoin < Arel::Nodes::Join
    end
  end
end
