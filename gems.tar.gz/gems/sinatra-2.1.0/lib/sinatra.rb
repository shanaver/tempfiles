require 'sinatra/main'

enable :inline_templates
