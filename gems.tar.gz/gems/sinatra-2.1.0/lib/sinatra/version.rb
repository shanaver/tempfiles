module Sinatra
  VERSION = '2.1.0'
end
